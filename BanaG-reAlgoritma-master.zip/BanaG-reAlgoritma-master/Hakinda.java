
public class Hakinda {

    public static void burpee_bilgi(){
        System.out.println("1)NASIL YAPILIR:\n"
                + " İlk önce bacaklarınız, birbirinden biraz ayrı olacak şekilde durun.\n"
                + " Vücudunuzu, squat pozisyonuna benzer şekilde çömelme noktasına gelene kadar indirin ve avuç içlerinizi,\n"
                + " göğsünüz hizasında yere koyun. Bacaklarınızı geriye doğru uzatın ve bedeninizi ayak uçlarınız ve ellerinizle\n"
                + " destekleyin.\n"
                + " Sonra dirseklerinizi bükün ve mümkün olduğunca bedeninizi yere yaklaştırın.\n"
                + " Kollarınızı uzatın ve dizlerinizi göğsünüze değecek şekilde bükün.\n"
                + " Son olarak zıplayarak ayağa kalkın. Bu sadece bir tekrar.\n"
                + " İster inanın ister inanmayın, her gün bu hareketi 100 kere yapar insanlar da var!\n\n" 
                + " 2)ÇALIŞTIRDIĞI KASLAR:\n"
                + " Göğüs – Pectoralis major : Şınav esnasında vücudu yukarı iterken çalışır.\n" 
                + " Arka kol – Triceps : Şınav esnasında çalışır.\n" 
                + " Omuz – Deltoids : Şınav esnasında vücudu itiş anında ve yukarı zıplarken kolları yukarı kaldırma anında çalışır.\n" 
                + " Ön bacak  – Quadriceps : Yukarı zıplama anında çalışır.\n" 
                + " Arka bacak – Hamstrings : Şınav pozisyonu bitiminde ayakları öne çekerken çalışır.\n" 
                + " Kalça – Glutes : Egzersizin tamamında çalışır.\n" 
                + " Baldır – Calves – Calfs : Zıplama esnasında çalışır.\n\n"
                + " 3)GÜNLÜK ÖNERİLEN:\n  30 Burpee"
              );
    }
    public static void pushup_bilgi(){
        System.out.println("1)NASIL YAPILIR:\n"
                + " Yere yüz üstü yatarak kalça kollardan güç alarak yukarı kaldırılır ve baş kollar ile aynı hizada ve kol arasında boştadır.\n"
                + " Eller arasındaki boşluk omuz genişliğindedir.\n" 
                + " Nefes vererek kol kırılır ve gövde kol arasından yay çizerek baş yukarı kalkar ve kalça düzelir ve yere yaklaşır\n"
                + " tekrar nefes verek ilk pozisyona ters  bir yay çizerek gönülür.\n" 
                + " Verilen tekrarlar yapılır ve 1 set bitirilir, verilen setleri’de tamamlayarak hareket sona erdirilir.\n"
                + " Farklı Hareketler arasında mutlaka 1 dakika dinlenin.\n\n"
                + "2)ÇALIŞTIRDIĞI KASLAR:\n"
                + " Omuz ,\n"
                + " Göğüs ,\n"
                + " Arka kol\n\n"
                + "3)GÜNLÜK ÖNERİLEN:\n 25 Push Up"
        );
    }
    public static void situp_bilgi(){
         System.out.println("1)NASIL YAPILIR:\n"
                 + "Eğimi 35-45 derece olan özel bir sehpa üzerine ayak bilekleri takılacak şekilde oturulur.\n"
                 + "Eller ensede veya göğüste birleştirilir.Gövde nefes alarak en arka pozisyona kadar gidilir,\n"
                 + "sırt sehpaya hafifçe temas ettikten sonra nefes verrilerek yavaşça başlangıç pozisyonuna dönülür.\n"
                 + "Hareketi yaparken sağ ve sol dize doğru eğilinirse belin yan kısımlarıda çalışılmış olur..\n" 
                 + "Sit-ups egzersizinin etkili olması için maksimum tekrar yapılmalı (ne kadar yapabilirseniz) sayılı yapılan tekrarlarda etkili sonuç alamazssınız.\n" 
                 + "Verilen tekrarlar yapılır ve 1 set bitiirilmiş olur, verilen setlerde tamamlanarak hareket sona erdirilir.\n"
                 + "Farklı Hareketler arasında mutlaka 1 dakika dinlenin.\n\n"
                 + "2)ÇALIŞTIRDIĞI KASLAR:\n"
                 + " Karın\n\n"
                 + "3)GÜNLÜK ÖNERİLEN:\n 45 Sit Up\n\n"
                 + "HATIRLATMA:\n"
                 + "Karın hareketlerine veya karın antrenmanına başlamadan 2 saat önce en son yemeği yiyin.\n"
                 + "Eğer tok karnına yaparsanız yemek dolayısıyla zaten kalbiniz idenize kan pompaladığı için , \n"
                 + "kalpte ritm artışı olabilir. Buda antrenman sırasında size sıkıntı verir , hatta kalp krizine neden olabilir.\n"
                 + "Antrenmana aç karnına gelin.Karın çalıştığınızda karın bölgesini sıcak tutacak bir kıyafet giyer veya kuşak sararsanız ,\n"
                 + "karın bölgesindeki yağların daha çabuk yakıldığını , hatta bu bölgedeki yağları hiç eritemeyenlerin bile zayıfladığını görürsünüz.");
    }
     public static void squat_bilgi(){
         System.out.println("1)NASIL YAPILIR:\n"
                 + " Yüzünüz karşıya bakmalı,\n"
                 + " kollar vücudunuza 90 derecelik açı yapacak şekilde öne doğru uzatılmış olmalı \n"
                 + "ve dizlerinizin bulunduğu ilk konumu değiştirmeden sırtınız dik duracak şekilde yapılmalıdır.\n"
                 + " Bu hareketi yapmadan önce mutlaka spor hocanızdan hareketi nasıl yapmanız gerektiği konusunda destek alınız.\n\n"
                 + "2)ÇALIŞTIRDIĞI KASLAR:\n" 
                 + "– Ön Bacak\n"
                 + "– Arka Bacak\n"
                 + "– Kalça Kasları\n"
                 + "- Sırt kasları\n"
                 + "– Karın kasları\n\n"
                 + "3)GÜNLÜK ÖNERİLEN:\n 50 Squat");
     }
}
