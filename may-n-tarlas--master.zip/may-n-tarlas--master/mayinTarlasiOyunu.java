
package mayintarlasi;

import javax.swing.JPanel;


 abstract class mayinTarlasiOyunu {
  
  
   
   public void oyunBitti(){
       
   }
  
 public void kareAcma(int x,int y){
     
 }
 

}
